package com.ecommerce.productService.service;
import com.ecommerce.productService.dto.request.*;
import com.ecommerce.productService.dto.request.CreateProductRequest.ProductSpecificationsRequest;
import com.ecommerce.productService.dto.request.CreateProductRequest.ProductVariantRequest;
import com.ecommerce.productService.dto.request.CreateProductRequest.SEORequest;

import com.ecommerce.productService.dto.response.*;
import com.ecommerce.productService.entity.Brand;
import com.ecommerce.productService.entity.Category;
import com.ecommerce.productService.entity.Product;
import com.ecommerce.productService.exception.ProductAlreadyExistsException;
import com.ecommerce.productService.exception.ResourceNotFoundException;
import com.ecommerce.productService.repository.BrandRepository;
import com.ecommerce.productService.repository.CategoryRepository;
import com.ecommerce.productService.repository.ProductRepository;
import com.github.slugify.Slugify;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductService {
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final BrandRepository brandRepository;
    private final Slugify slugify = Slugify.builder().build();

    // ============================================
    // CREATE PRODUCT
    // ============================================

    @Transactional
    public ProductResponse createProduct(CreateProductRequest request) {
        log.info("Creating product: {}", request.getName());

        // Check if SKU already exists
        if (productRepository.existsBySku(request.getSku())) {
            throw new ProductAlreadyExistsException("Product with SKU " + request.getSku() + " already exists");
        }

        // Generate unique slug
        String slug = generateUniqueSlug(request.getName());

        // Verify category exists
        Category category = categoryRepository.findByParentCategoryId(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        // Verify brand exists (if provided)
        Brand brand = null;
        if (request.getBrandId() != null && !request.getBrandId().isEmpty()) {
            brand = brandRepository.findByBrandName(request.getBrandId())
                    .orElseThrow(() -> new ResourceNotFoundException("Brand not found"));
        }

        // Build product entity
        Product product = Product.builder()
                .productId(UUID.randomUUID().toString())
                .name(request.getName())
                .slug(slug)
                .description(request.getDescription())
                .shortDescription(request.getShortDescription())
                .categoryId(request.getCategoryId())
                .brandId(request.getBrandId())
                .sku(request.getSku())
                .basePrice(request.getBasePrice())
                .currency(request.getCurrency())
                .taxPercentage(request.getTaxPercentage())
                .isActive(request.getIsActive())
                .isFeatured(request.getIsFeatured())
                .tags(request.getTags())
                .images(mapImages(request.getImageUrls()))
                .specifications(mapSpecifications(request.getSpecifications()))
                .variants(mapVariants(request.getVariants()))
                .seo(mapSEO(request.getSeo()))
                .totalQuantity(request.getTotalQuantity() != null ? request.getTotalQuantity() : 0)
                .ratingAverage(0.0)
                .reviewCount(0)
                .viewCount(0L)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        // Save to MongoDB
        Product savedProduct = productRepository.save(product);

        log.info("Product created successfully: {}", savedProduct.getProductId());

        return mapToProductResponse(savedProduct, category, brand);
    }

    // ============================================
    // UPDATE PRODUCT
    // ============================================

    @Transactional
    public ProductResponse updateProduct(String productId, UpdateProductRequest request) {
        log.info("Updating product: {}", productId);

        Product product = productRepository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        // Update fields if provided
        if (request.getName() != null && !request.getName().equals(product.getName())) {
            product.setName(request.getName());
            product.setSlug(generateUniqueSlug(request.getName()));
        }

        if (request.getDescription() != null) product.setDescription(request.getDescription());
        if (request.getShortDescription() != null) product.setShortDescription(request.getShortDescription());
        if (request.getCategoryId() != null) product.setCategoryId(request.getCategoryId());
        if (request.getBrandId() != null) product.setBrandId(request.getBrandId());
        if (request.getSku() != null) product.setSku(request.getSku());
        if (request.getBasePrice() != null) product.setBasePrice(request.getBasePrice());
        if (request.getCurrency() != null) product.setCurrency(request.getCurrency());
        if (request.getTaxPercentage() != null) product.setTaxPercentage(request.getTaxPercentage());
        if (request.getIsActive() != null) product.setIsActive(request.getIsActive());
        if (request.getIsFeatured() != null) product.setIsFeatured(request.getIsFeatured());
        if (request.getTags() != null) product.setTags(request.getTags());
        if (request.getImageUrls() != null) product.setImages(mapImages(request.getImageUrls()));
        if (request.getSpecifications() != null) product.setSpecifications(mapSpecifications(request.getSpecifications()));
        if (request.getVariants() != null) product.setVariants(mapVariants(request.getVariants()));
        if (request.getSeo() != null) product.setSeo(mapSEO(request.getSeo()));
        if (request.getTotalQuantity() != null) product.setTotalQuantity(request.getTotalQuantity());

        product.setUpdatedAt(LocalDateTime.now());

        // Save
        Product updatedProduct = productRepository.save(product);

        Category category = categoryRepository.findByCategoryId(updatedProduct.getCategoryId()).orElse(null);
        Brand brand = updatedProduct.getBrandId() != null ? brandRepository.findByBrandId(updatedProduct.getBrandId()).orElse(null) : null;

        log.info("Product updated successfully: {}", productId);

        return mapToProductResponse(updatedProduct, category, brand);
    }

    // ============================================
    // GET PRODUCT BY ID
    // ============================================

    public ProductResponse getProductById(String productId) {
        log.info("Fetching product: {}", productId);

        Product product = productRepository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        // Increment view count
        product.setViewCount(product.getViewCount() + 1);
        productRepository.save(product);

        Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
        Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;

        return mapToProductResponse(product, category, brand);
    }

    // ============================================
    // GET PRODUCT BY SLUG
    // ============================================

    public ProductResponse getProductBySlug(String slug) {
        log.info("Fetching product by slug: {}", slug);

        Product product = productRepository.findBySlug(slug)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        // Increment view count
        product.setViewCount(product.getViewCount() + 1);
        productRepository.save(product);

        Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
        Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;

        return mapToProductResponse(product, category, brand);
    }

    // ============================================
    // GET ALL PRODUCTS
    // ============================================

    public Page<ProductResponse> getAllProducts(Pageable pageable) {
        log.info("Fetching all products - Page: {}, Size: {}", pageable.getPageNumber(), pageable.getPageSize());

        Page<Product> products = productRepository.findAll(pageable);

        return products.map(product -> {
            Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
            Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // SEARCH PRODUCTS (MongoDB text search)
    // ============================================

    public Page<ProductResponse> searchProducts(String query, Pageable pageable) {
        log.info("Searching products with query: {}", query);

        Page<Product> searchResults = productRepository.searchByNameOrDescription(query, pageable);

        return searchResults.map(product -> {
            Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
            Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // GET PRODUCTS BY CATEGORY
    // ============================================

    public Page<ProductResponse> getProductsByCategory(String categoryId, Pageable pageable) {
        log.info("Fetching products for category: {}", categoryId);

        Page<Product> products = productRepository.findByCategoryId(categoryId, pageable);

        Category category = categoryRepository.findByCategoryId(categoryId).orElse(null);

        return products.map(product -> {
            Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // GET PRODUCTS BY BRAND
    // ============================================

    public Page<ProductResponse> getProductsByBrand(String brandId, Pageable pageable) {
        log.info("Fetching products for brand: {}", brandId);

        Page<Product> products = productRepository.findByBrandId(brandId, pageable);

        Brand brand = brandRepository.findByBrandId(brandId).orElse(null);

        return products.map(product -> {
            Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // GET FEATURED PRODUCTS
    // ============================================

    public Page<ProductResponse> getFeaturedProducts(Pageable pageable) {
        log.info("Fetching featured products");

        Page<Product> products = productRepository.findByIsFeatured(true, pageable);

        return products.map(product -> {
            Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
            Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // GET ACTIVE PRODUCTS
    // ============================================

    public Page<ProductResponse> getActiveProducts(Pageable pageable) {
        log.info("Fetching active products");

        Page<Product> products = productRepository.findByIsActive(true, pageable);

        return products.map(product -> {
            Category category = categoryRepository.findByCategoryId(product.getCategoryId()).orElse(null);
            Brand brand = product.getBrandId() != null ? brandRepository.findByBrandId(product.getBrandId()).orElse(null) : null;
            return mapToProductResponse(product, category, brand);
        });
    }

    // ============================================
    // DELETE PRODUCT
    // ============================================

    @Transactional
    public void deleteProduct(String productId) {
        log.info("Deleting product: {}", productId);

        Product product = productRepository.findByProductId(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));

        productRepository.delete(product);

        log.info("Product deleted successfully: {}", productId);
    }

    // ============================================
    // HELPER METHODS - SLUG GENERATION
    // ============================================

    private String generateUniqueSlug(String name) {
        String baseSlug = slugify.slugify(name);
        String slug = baseSlug;
        int counter = 1;

        while (productRepository.existsBySlug(slug)) {
            slug = baseSlug + "-" + counter++;
        }

        return slug;
    }

    // ============================================
    // HELPER METHODS - MAPPING REQUEST TO ENTITY
    // ============================================

    private List<Product.ProductImage> mapImages(List<String> imageUrls) {
        if (imageUrls == null || imageUrls.isEmpty()) return null;

        List<Product.ProductImage> images = new ArrayList<>();
        for (int i = 0; i < imageUrls.size(); i++) {
            images.add(Product.ProductImage.builder()
                    .url(imageUrls.get(i))
                    .isPrimary(i == 0)
                    .displayOrder(i)
                    .build());
        }
        return images;
    }

    private Product.ProductSpecifications mapSpecifications(ProductSpecificationsRequest request) {
        if (request == null) return null;

        List<Product.KeyValue> additionalSpecs = null;
        if (request.getAdditionalSpecs() != null) {
            additionalSpecs = request.getAdditionalSpecs().stream()
                    .map(spec -> Product.KeyValue.builder()
                            .key(spec.getKey())
                            .value(spec.getValue())
                            .build())
                    .collect(Collectors.toList());
        }

        return Product.ProductSpecifications.builder()
                .weight(request.getWeight())
                .dimensions(request.getDimensions())
                .material(request.getMaterial())
                .color(request.getColor())
                .warranty(request.getWarranty())
                .additionalSpecs(additionalSpecs)
                .build();
    }

    private List<Product.ProductVariant> mapVariants(List<ProductVariantRequest> requests) {
        if (requests == null || requests.isEmpty()) return null;

        return requests.stream()
                .map(request -> {
                    Product.VariantAttributes attributes = null;
                    if (request.getAttributes() != null) {
                        attributes = Product.VariantAttributes.builder()
                                .size(request.getAttributes().getSize())
                                .color(request.getAttributes().getColor())
                                .storage(request.getAttributes().getStorage())
                                .model(request.getAttributes().getModel())
                                .build();
                    }

                    return Product.ProductVariant.builder()
                            .variantId(UUID.randomUUID().toString())
                            .sku(request.getSku())
                            .name(request.getName())
                            .attributes(attributes)
                            .price(request.getPrice())
                            .compareAtPrice(request.getCompareAtPrice())
                            .costPrice(request.getCostPrice())
                            .images(request.getImages())
                            .quantity(request.getQuantity())
                            .isAvailable(request.getIsAvailable())
                            .build();
                })
                .collect(Collectors.toList());
    }

    private Product.SEO mapSEO(SEORequest request) {
        if (request == null) return null;

        return Product.SEO.builder()
                .metaTitle(request.getMetaTitle())
                .metaDescription(request.getMetaDescription())
                .metaKeywords(request.getMetaKeywords())
                .canonicalUrl(request.getCanonicalUrl())
                .build();
    }

    // ============================================
    // HELPER METHODS - MAPPING ENTITY TO RESPONSE
    // ============================================

    private ProductResponse mapToProductResponse(Product product, Category category, Brand brand) {
        return ProductResponse.builder()
                .productId(product.getProductId())
                .name(product.getName())
                .slug(product.getSlug())
                .description(product.getDescription())
                .shortDescription(product.getShortDescription())
                .category(category != null ? mapToCategoryResponse(category) : null)
                .brand(brand != null ? mapToBrandResponse(brand) : null)
                .sku(product.getSku())
                .basePrice(product.getBasePrice())
                .currency(product.getCurrency())
                .taxPercentage(product.getTaxPercentage())
                .isActive(product.getIsActive())
                .isFeatured(product.getIsFeatured())
                .tags(product.getTags())
                .images(mapToImageResponses(product.getImages()))
                .specifications(mapToSpecificationsResponse(product.getSpecifications()))
                .variants(mapToVariantResponses(product.getVariants()))
                .seo(mapToSEOResponse(product.getSeo()))
                .totalQuantity(product.getTotalQuantity())
                .ratingAverage(product.getRatingAverage())
                .reviewCount(product.getReviewCount())
                .viewCount(product.getViewCount())
                .createdAt(product.getCreatedAt())
                .updatedAt(product.getUpdatedAt())
                .build();
    }

    private List<ProductImageResponse> mapToImageResponses(List<Product.ProductImage> images) {
        if (images == null) return null;

        return images.stream()
                .map(image -> ProductImageResponse.builder()
                        .url(image.getUrl())
                        .altText(image.getAltText())
                        .isPrimary(image.getIsPrimary())
                        .displayOrder(image.getDisplayOrder())
                        .build())
                .collect(Collectors.toList());
    }

    private ProductSpecificationsResponse mapToSpecificationsResponse(Product.ProductSpecifications specs) {
        if (specs == null) return null;

        List<KeyValueResponse> additionalSpecs = null;
        if (specs.getAdditionalSpecs() != null) {
            additionalSpecs = specs.getAdditionalSpecs().stream()
                    .map(kv -> KeyValueResponse.builder()
                            .key(kv.getKey())
                            .value(kv.getValue())
                            .build())
                    .collect(Collectors.toList());
        }

        return ProductSpecificationsResponse.builder()
                .weight(specs.getWeight())
                .dimensions(specs.getDimensions())
                .material(specs.getMaterial())
                .color(specs.getColor())
                .warranty(specs.getWarranty())
                .additionalSpecs(additionalSpecs)
                .build();
    }

    private List<ProductVariantResponse> mapToVariantResponses(List<Product.ProductVariant> variants) {
        if (variants == null) return null;

        return variants.stream()
                .map(variant -> {
                    VariantAttributesResponse attributes = null;
                    if (variant.getAttributes() != null) {
                        attributes = VariantAttributesResponse.builder()
                                .size(variant.getAttributes().getSize())
                                .color(variant.getAttributes().getColor())
                                .storage(variant.getAttributes().getStorage())
                                .model(variant.getAttributes().getModel())
                                .build();
                    }

                    return ProductVariantResponse.builder()
                            .variantId(variant.getVariantId())
                            .sku(variant.getSku())
                            .name(variant.getName())
                            .attributes(attributes)
                            .price(variant.getPrice())
                            .compareAtPrice(variant.getCompareAtPrice())
                            .costPrice(variant.getCostPrice())
                            .images(variant.getImages())
                            .quantity(variant.getQuantity())
                            .isAvailable(variant.getIsAvailable())
                            .build();
                })
                .collect(Collectors.toList());
    }

    private SEOResponse mapToSEOResponse(Product.SEO seo) {
        if (seo == null) return null;

        return SEOResponse.builder()
                .metaTitle(seo.getMetaTitle())
                .metaDescription(seo.getMetaDescription())
                .metaKeywords(seo.getMetaKeywords())
                .canonicalUrl(seo.getCanonicalUrl())
                .build();
    }

    private CategoryResponse mapToCategoryResponse(Category category) {
        return CategoryResponse.builder()
                .categoryId(category.getCategoryId())
                .categoryName(category.getCategoryName())
                .slug(category.getSlug())
                .description(category.getDescription())
                .parentCategoryId(category.getParentCategoryId())
                .imageUrl(category.getImageUrl())
                .isActive(category.getIsActive())
                .displayOrder(category.getDisplayOrder())
                .metaTitle(category.getMetaTitle())
                .metaDescription(category.getMetaDescription())
                .createdAt(category.getCreatedAt())
                .updatedAt(category.getUpdatedAt())
                .build();
    }

    private BrandResponse mapToBrandResponse(Brand brand) {
        return BrandResponse.builder()
                .brandId(brand.getBrandId())
                .brandName(brand.getBrandName())
                .slug(brand.getSlug())
                .description(brand.getDescription())
                .logoUrl(brand.getLogoUrl())
                .website(brand.getWebsite())
                .isActive(brand.getIsActive())
                .createdAt(brand.getCreatedAt())
                .updatedAt(brand.getUpdatedAt())
                .build();
    }
}
