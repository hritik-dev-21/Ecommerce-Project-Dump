package com.ecommerce.productService.entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "categories")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Category {
    @Id
    private String id;

    @Indexed(unique = true)
    private String categoryId;

    @Indexed
    private String categoryName;

    @Indexed(unique = true)
    private String slug;

    private String description;
    private String parentCategoryId;
    private String imageUrl;

    @Indexed
    private Boolean isActive;

    private Integer displayOrder;

    private String metaTitle;
    private String metaDescription;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
