package com.ecommerce.productService.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductImageResponse {
    private String url;
    private String altText;
    private Boolean isPrimary;
    private Integer displayOrder;
}
