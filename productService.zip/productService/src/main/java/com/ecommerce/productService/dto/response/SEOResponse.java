package com.ecommerce.productService.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SEOResponse {
    private String metaTitle;
    private String metaDescription;
    private List<String> metaKeywords;
    private String canonicalUrl;
}
