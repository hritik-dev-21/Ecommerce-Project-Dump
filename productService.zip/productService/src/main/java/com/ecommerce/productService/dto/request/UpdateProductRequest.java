package com.ecommerce.productService.dto.request;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class UpdateProductRequest {
    @Size(min = 3, max = 255, message = "Product name must be between 3 and 255 characters")
    private String name;

    private String description;

    @Size(max = 500, message = "Short description must not exceed 500 characters")
    private String shortDescription;

    private String categoryId;
    private String brandId;
    private String sku;

    @DecimalMin(value = "0.01", message = "Price must be greater than 0")
    private BigDecimal basePrice;

    @Size(min = 3, max = 3, message = "Currency must be 3 characters")
    private String currency;

    @DecimalMin(value = "0.0", message = "Tax percentage cannot be negative")
    @DecimalMax(value = "100.0", message = "Tax percentage cannot exceed 100")
    private Double taxPercentage;

    private Boolean isActive;
    private Boolean isFeatured;

    private List<String> tags;
    private List<String> imageUrls;

    private CreateProductRequest.ProductSpecificationsRequest specifications;
    private List<CreateProductRequest.ProductVariantRequest> variants;
    private CreateProductRequest.SEORequest seo;

    @Min(value = 0, message = "Quantity cannot be negative")
    private Integer totalQuantity;
}
