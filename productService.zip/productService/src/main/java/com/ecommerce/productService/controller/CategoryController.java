package com.ecommerce.productService.controller;
import com.ecommerce.productService.dto.request.CreateCategoryRequest;
import com.ecommerce.productService.dto.response.ApiResponse;
import com.ecommerce.productService.dto.response.CategoryResponse;
import com.ecommerce.productService.service.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CategoryController {
    private final CategoryService categoryService;

    @PostMapping
    public ResponseEntity<ApiResponse> createCategory(@Valid @RequestBody CreateCategoryRequest request) {
        CategoryResponse category = categoryService.createCategory(request);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Category created successfully")
                .data(category)
                .build();
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{categoryId}")
    public ResponseEntity<CategoryResponse> getCategoryById(@PathVariable String categoryId) {
        CategoryResponse category = categoryService.getCategoryById(categoryId);
        return ResponseEntity.ok(category);
    }

    @GetMapping
    public ResponseEntity<Page<CategoryResponse>> getAllCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<CategoryResponse> categories = categoryService.getAllCategories(pageable);
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/active")
    public ResponseEntity<List<CategoryResponse>> getActiveCategories() {
        List<CategoryResponse> categories = categoryService.getActiveCategories();
        return ResponseEntity.ok(categories);
    }

//    @GetMapping("/parent/{parentId}")
//    public ResponseEntity<List<CategoryResponse>> getSubCategories(@PathVariable String parentId) {
//        List<CategoryResponse> categories = categoryService.getSubCategories(parentId);
//        return ResponseEntity.ok(categories);
//    }

    @PutMapping("/{categoryId}")
    public ResponseEntity<ApiResponse> updateCategory(
            @PathVariable String categoryId,
            @Valid @RequestBody CreateCategoryRequest request) {

        CategoryResponse category = categoryService.updateCategory(categoryId, request);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Category updated successfully")
                .data(category)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{categoryId}")
    public ResponseEntity<ApiResponse> deleteCategory(@PathVariable String categoryId) {
        categoryService.deleteCategory(categoryId);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Category deleted successfully")
                .build();
        return ResponseEntity.ok(response);
    }
}
