package com.ecommerce.productService.entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
@Document(collection = "products")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    private String id;

    @Indexed(unique = true)
    private String productId; // UUID as String

    @Indexed
    private String name;

    @Indexed(unique = true)
    private String slug;

    private String description;
    private String shortDescription;

    @Indexed
    private String categoryId;

    private String brandId;

    @Indexed
    private String sku;

    private BigDecimal basePrice;
    private String currency;
    private Double taxPercentage;

    @Indexed
    private Boolean isActive;
    private Boolean isFeatured;

    @Indexed
    private List<String> tags;

    private List<ProductImage> images;
    private ProductSpecifications specifications;
    private List<ProductVariant> variants;

    private SEO seo;

    private Integer totalQuantity;
    private Double ratingAverage;
    private Integer reviewCount;
    private Long viewCount;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductImage {
        private String url;
        private String altText;
        private Boolean isPrimary;
        private Integer displayOrder;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductSpecifications {
        private String weight;
        private String dimensions;
        private String material;
        private String color;
        private String warranty;
        private List<KeyValue> additionalSpecs;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class KeyValue {
        private String key;
        private String value;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductVariant {
        private String variantId;
        private String sku;
        private String name;
        private VariantAttributes attributes;
        private BigDecimal price;
        private BigDecimal compareAtPrice;
        private BigDecimal costPrice;
        private List<String> images;
        private Integer quantity;
        private Boolean isAvailable;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class VariantAttributes {
        private String size;
        private String color;
        private String storage;
        private String model;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SEO {
        private String metaTitle;
        private String metaDescription;
        private List<String> metaKeywords;
        private String canonicalUrl;
    }
}
