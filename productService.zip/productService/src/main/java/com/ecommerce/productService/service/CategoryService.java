package com.ecommerce.productService.service;
import com.ecommerce.productService.dto.request.CreateCategoryRequest;
import com.ecommerce.productService.dto.response.CategoryResponse;
import com.ecommerce.productService.entity.Category;
import com.ecommerce.productService.exception.ResourceNotFoundException;
import com.ecommerce.productService.repository.CategoryRepository;
import com.github.slugify.Slugify;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CategoryService {
    private final CategoryRepository categoryRepository;
    private final Slugify slugify = Slugify.builder().build();

    @Transactional
    public CategoryResponse createCategory(CreateCategoryRequest request) {
        log.info("Creating category: {}", request.getCategoryName());

        String slug = generateUniqueSlug(request.getCategoryName());

        Category category = Category.builder()
                .categoryId(UUID.randomUUID().toString())
                .categoryName(request.getCategoryName())
                .slug(slug)
                .description(request.getDescription())
                .parentCategoryId(request.getParentCategoryId())
                .imageUrl(request.getImageUrl())
                .isActive(request.getIsActive())
                .displayOrder(request.getDisplayOrder())
                .metaTitle(request.getMetaTitle())
                .metaDescription(request.getMetaDescription())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Category savedCategory = categoryRepository.save(category);

        log.info("Category created successfully: {}", savedCategory.getCategoryId());

        return mapToCategoryResponse(savedCategory);
    }

    public CategoryResponse getCategoryById(String categoryId) {
        log.info("Fetching category: {}", categoryId);

        Category category = categoryRepository.findByCategoryId(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        return mapToCategoryResponse(category);
    }

    public Page<CategoryResponse> getAllCategories(Pageable pageable) {
        log.info("Fetching all categories");

        Page<Category> categories = categoryRepository.findAll(pageable);
        return categories.map(this::mapToCategoryResponse);
    }

    public List<CategoryResponse> getActiveCategories() {
        log.info("Fetching active categories");

        List<Category> categories = categoryRepository.findByIsActive(true);
        return categories.stream()
                .map(this::mapToCategoryResponse)
                .collect(Collectors.toList());
    }

//    public List<CategoryResponse> getSubCategories(String parentCategoryId) {
//        log.info("Fetching sub-categories for: {}", parentCategoryId);
//
//        List<Category> categories = categoryRepository.findByParentCategoryId(parentCategoryId);
//        return categories.stream()
//                .map(this::mapToCategoryResponse)
//                .collect(Collectors.toList());
//    }

    @Transactional
    public CategoryResponse updateCategory(String categoryId, CreateCategoryRequest request) {
        log.info("Updating category: {}", categoryId);

        Category category = categoryRepository.findByCategoryId(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        if (request.getCategoryName() != null && !request.getCategoryName().equals(category.getCategoryName())) {
            category.setCategoryName(request.getCategoryName());
            category.setSlug(generateUniqueSlug(request.getCategoryName()));
        }

        if (request.getDescription() != null) category.setDescription(request.getDescription());
        if (request.getParentCategoryId() != null) category.setParentCategoryId(request.getParentCategoryId());
        if (request.getImageUrl() != null) category.setImageUrl(request.getImageUrl());
        if (request.getIsActive() != null) category.setIsActive(request.getIsActive());
        if (request.getDisplayOrder() != null) category.setDisplayOrder(request.getDisplayOrder());
        if (request.getMetaTitle() != null) category.setMetaTitle(request.getMetaTitle());
        if (request.getMetaDescription() != null) category.setMetaDescription(request.getMetaDescription());

        category.setUpdatedAt(LocalDateTime.now());

        Category updatedCategory = categoryRepository.save(category);

        log.info("Category updated successfully: {}", categoryId);

        return mapToCategoryResponse(updatedCategory);
    }

    @Transactional
    public void deleteCategory(String categoryId) {
        log.info("Deleting category: {}", categoryId);

        Category category = categoryRepository.findByCategoryId(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        categoryRepository.delete(category);

        log.info("Category deleted successfully: {}", categoryId);
    }

    private String generateUniqueSlug(String name) {
        String baseSlug = slugify.slugify(name);
        String slug = baseSlug;
        int counter = 1;

        while (categoryRepository.existsBySlug(slug)) {
            slug = baseSlug + "-" + counter++;
        }

        return slug;
    }

    private CategoryResponse mapToCategoryResponse(Category category) {
        return CategoryResponse.builder()
                .categoryId(category.getCategoryId())
                .categoryName(category.getCategoryName())
                .slug(category.getSlug())
                .description(category.getDescription())
                .parentCategoryId(category.getParentCategoryId())
                .imageUrl(category.getImageUrl())
                .isActive(category.getIsActive())
                .displayOrder(category.getDisplayOrder())
                .metaTitle(category.getMetaTitle())
                .metaDescription(category.getMetaDescription())
                .createdAt(category.getCreatedAt())
                .updatedAt(category.getUpdatedAt())
                .build();
    }
}
