package com.ecommerce.productService.controller;
import com.ecommerce.productService.dto.request.CreateBrandRequest;
import com.ecommerce.productService.dto.response.ApiResponse;
import com.ecommerce.productService.dto.response.BrandResponse;
import com.ecommerce.productService.service.BrandService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/brands")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class BrandController {
    private final BrandService brandService;

    @PostMapping
    public ResponseEntity<ApiResponse> createBrand(@Valid @RequestBody CreateBrandRequest request) {
        BrandResponse brand = brandService.createBrand(request);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Brand created successfully")
                .data(brand)
                .build();
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{brandId}")
    public ResponseEntity<BrandResponse> getBrandById(@PathVariable String brandId) {
        BrandResponse brand = brandService.getBrandById(brandId);
        return ResponseEntity.ok(brand);
    }

    @GetMapping
    public ResponseEntity<Page<BrandResponse>> getAllBrands(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<BrandResponse> brands = brandService.getAllBrands(pageable);
        return ResponseEntity.ok(brands);
    }

    @GetMapping("/active")
    public ResponseEntity<List<BrandResponse>> getActiveBrands() {
        List<BrandResponse> brands = brandService.getActiveBrands();
        return ResponseEntity.ok(brands);
    }

    @PutMapping("/{brandId}")
    public ResponseEntity<ApiResponse> updateBrand(
            @PathVariable String brandId,
            @Valid @RequestBody CreateBrandRequest request) {

        BrandResponse brand = brandService.updateBrand(brandId, request);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Brand updated successfully")
                .data(brand)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{brandId}")
    public ResponseEntity<ApiResponse> deleteBrand(@PathVariable String brandId) {
        brandService.deleteBrand(brandId);
        ApiResponse response = ApiResponse.builder()
                .success(true)
                .message("Brand deleted successfully")
                .build();
        return ResponseEntity.ok(response);
    }
}
