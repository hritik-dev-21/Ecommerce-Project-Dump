package com.ecommerce.productService.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class CreateProductRequest {
    @NotBlank(message = "Product name is required")
    @Size(min = 3, max = 255, message = "Product name must be between 3 and 255 characters")
    private String name;

    @NotBlank(message = "Description is required")
    private String description;

    @Size(max = 500, message = "Short description must not exceed 500 characters")
    private String shortDescription;

    @NotBlank(message = "Category is required")
    private String categoryId;

    private String brandId;

    @NotBlank(message = "SKU is required")
    private String sku;

    @NotNull(message = "Base price is required")
    @DecimalMin(value = "0.01", message = "Price must be greater than 0")
    private BigDecimal basePrice;

    @NotBlank(message = "Currency is required")
    @Size(min = 3, max = 3, message = "Currency must be 3 characters (e.g., USD)")
    private String currency;

    @DecimalMin(value = "0.0", message = "Tax percentage cannot be negative")
    @DecimalMax(value = "100.0", message = "Tax percentage cannot exceed 100")
    private Double taxPercentage;

    private Boolean isActive = true;
    private Boolean isFeatured = false;

    private List<String> tags;

    private List<String> imageUrls;

    private ProductSpecificationsRequest specifications;

    private List<ProductVariantRequest> variants;

    private SEORequest seo;

    @Min(value = 0, message = "Quantity cannot be negative")
    private Integer totalQuantity;

    @Data
    public static class ProductSpecificationsRequest {
        private String weight;
        private String dimensions;
        private String material;
        private String color;
        private String warranty;
        private List<KeyValueRequest> additionalSpecs;
    }

    @Data
    public static class KeyValueRequest {
        private String key;
        private String value;
    }

    @Data
    public static class ProductVariantRequest {
        @NotBlank(message = "Variant SKU is required")
        private String sku;

        private String name;
        private VariantAttributesRequest attributes;

        @NotNull(message = "Variant price is required")
        private BigDecimal price;

        private BigDecimal compareAtPrice;
        private BigDecimal costPrice;
        private List<String> images;

        @Min(value = 0, message = "Quantity cannot be negative")
        private Integer quantity;

        private Boolean isAvailable = true;
    }

    @Data
    public static class VariantAttributesRequest {
        private String size;
        private String color;
        private String storage;
        private String model;
    }

    @Data
    public static class SEORequest {
        @Size(max = 60, message = "Meta title should not exceed 60 characters")
        private String metaTitle;

        @Size(max = 160, message = "Meta description should not exceed 160 characters")
        private String metaDescription;

        private List<String> metaKeywords;
        private String canonicalUrl;
    }
}
