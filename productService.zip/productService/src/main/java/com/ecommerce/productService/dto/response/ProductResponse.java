package com.ecommerce.productService.dto.response;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductResponse {
    private String productId;
    private String name;
    private String slug;
    private String description;
    private String shortDescription;

    private CategoryResponse category;
    private BrandResponse brand;

    private String sku;
    private BigDecimal basePrice;
    private String currency;
    private Double taxPercentage;

    private Boolean isActive;
    private Boolean isFeatured;

    private List<String> tags;
    private List<ProductImageResponse> images;
    private ProductSpecificationsResponse specifications;
    private List<ProductVariantResponse> variants;
    private SEOResponse seo;

    private Integer totalQuantity;
    private Double ratingAverage;
    private Integer reviewCount;
    private Long viewCount;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
