package com.ecommerce.productService.repository;

import com.ecommerce.productService.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends MongoRepository<Product, String>{
    Optional<Product> findByProductId(String productId);
    Optional<Product> findBySlug(String slug);
    Optional<Product> findBySku(String sku);

    Page<Product> findByIsActive(Boolean isActive, Pageable pageable);
    Page<Product> findByIsFeatured(Boolean isFeatured, Pageable pageable);
    Page<Product> findByCategoryId(String categoryId, Pageable pageable);
    Page<Product> findByBrandId(String brandId, Pageable pageable);
    Page<Product> findByTagsContaining(String tag, Pageable pageable);

    // Search by name or description (case-insensitive)
    @Query("{ $or: [ { 'name': { $regex: ?0, $options: 'i' } }, { 'description': { $regex: ?0, $options: 'i' } } ] }")
    Page<Product> searchByNameOrDescription(String query, Pageable pageable);

    List<Product> findTop10ByOrderByViewCountDesc();
    List<Product> findTop10ByOrderByCreatedAtDesc();

    Boolean existsByProductId(String productId);
    Boolean existsBySlug(String slug);
    Boolean existsBySku(String sku);
}
