package com.ecommerce.productService.repository;
import com.ecommerce.productService.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends MongoRepository<Category, String>{
    Optional<Category> findByCategoryId(String categoryId);
    Optional<Category> findBySlug(String slug);

    List<Category> findByIsActive(Boolean isActive);
    Optional<Category> findByParentCategoryId(String parentCategoryId);
    Page<Category> findByIsActive(Boolean isActive, Pageable pageable);

    Boolean existsByCategoryId(String categoryId);
    Boolean existsBySlug(String slug);
}
