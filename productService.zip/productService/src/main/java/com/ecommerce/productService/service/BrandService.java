package com.ecommerce.productService.service;
import com.ecommerce.productService.dto.request.CreateBrandRequest;
import com.ecommerce.productService.dto.response.BrandResponse;
import com.ecommerce.productService.entity.Brand;
import com.ecommerce.productService.exception.ResourceNotFoundException;
import com.ecommerce.productService.repository.BrandRepository;
import com.github.slugify.Slugify;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BrandService {
    private final BrandRepository brandRepository;
    private final Slugify slugify = Slugify.builder().build();

    @Transactional
    public BrandResponse createBrand(CreateBrandRequest request) {
        log.info("Creating brand: {}", request.getBrandName());

        String slug = generateUniqueSlug(request.getBrandName());

        Brand brand = Brand.builder()
                .brandId(UUID.randomUUID().toString())
                .brandName(request.getBrandName())
                .slug(slug)
                .description(request.getDescription())
                .logoUrl(request.getLogoUrl())
                .website(request.getWebsite())
                .isActive(request.getIsActive())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Brand savedBrand = brandRepository.save(brand);

        log.info("Brand created successfully: {}", savedBrand.getBrandId());

        return mapToBrandResponse(savedBrand);
    }

    public BrandResponse getBrandById(String brandId) {
        log.info("Fetching brand: {}", brandId);

        Brand brand = brandRepository.findByBrandId(brandId)
                .orElseThrow(() -> new ResourceNotFoundException("Brand not found"));

        return mapToBrandResponse(brand);
    }

    public Page<BrandResponse> getAllBrands(Pageable pageable) {
        log.info("Fetching all brands");

        Page<Brand> brands = brandRepository.findAll(pageable);
        return brands.map(this::mapToBrandResponse);
    }

    public List<BrandResponse> getActiveBrands() {
        log.info("Fetching active brands");

        List<Brand> brands = brandRepository.findByIsActive(true);
        return brands.stream()
                .map(this::mapToBrandResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public BrandResponse updateBrand(String brandId, CreateBrandRequest request) {
        log.info("Updating brand: {}", brandId);

        Brand brand = brandRepository.findByBrandId(brandId)
                .orElseThrow(() -> new ResourceNotFoundException("Brand not found"));

        if (request.getBrandName() != null && !request.getBrandName().equals(brand.getBrandName())) {
            brand.setBrandName(request.getBrandName());
            brand.setSlug(generateUniqueSlug(request.getBrandName()));
        }

        if (request.getDescription() != null) brand.setDescription(request.getDescription());
        if (request.getLogoUrl() != null) brand.setLogoUrl(request.getLogoUrl());
        if (request.getWebsite() != null) brand.setWebsite(request.getWebsite());
        if (request.getIsActive() != null) brand.setIsActive(request.getIsActive());

        brand.setUpdatedAt(LocalDateTime.now());

        Brand updatedBrand = brandRepository.save(brand);

        log.info("Brand updated successfully: {}", brandId);

        return mapToBrandResponse(updatedBrand);
    }

    @Transactional
    public void deleteBrand(String brandId) {
        log.info("Deleting brand: {}", brandId);

        Brand brand = brandRepository.findByBrandId(brandId)
                .orElseThrow(() -> new ResourceNotFoundException("Brand not found"));

        brandRepository.delete(brand);

        log.info("Brand deleted successfully: {}", brandId);
    }

    private String generateUniqueSlug(String name) {
        String baseSlug = slugify.slugify(name);
        String slug = baseSlug;
        int counter = 1;

        while (brandRepository.existsBySlug(slug)) {
            slug = baseSlug + "-" + counter++;
        }

        return slug;
    }

    private BrandResponse mapToBrandResponse(Brand brand) {
        return BrandResponse.builder()
                .brandId(brand.getBrandId())
                .brandName(brand.getBrandName())
                .slug(brand.getSlug())
                .description(brand.getDescription())
                .logoUrl(brand.getLogoUrl())
                .website(brand.getWebsite())
                .isActive(brand.getIsActive())
                .createdAt(brand.getCreatedAt())
                .updatedAt(brand.getUpdatedAt())
                .build();
    }
}
